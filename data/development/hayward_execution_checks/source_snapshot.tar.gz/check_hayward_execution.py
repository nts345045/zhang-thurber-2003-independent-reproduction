import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from types import SimpleNamespace

root = Path.cwd()
target = root/'tmp/hayward_execution_checks'
target.mkdir()
source = root/'run_hayward_first_arrival.py'
fixture = target/'fixture'
(fixture/'data/hayward').mkdir(parents=True)
(fixture/'configs').mkdir()
(fixture/'src').mkdir()
(fixture/'bin').mkdir()
shutil.copyfile(str(source), str(fixture/source.name))
for name in ['initial_events.csv','initial_grid.csv','stations.csv','observations.csv',
             'selection_manifest.json','authoritative_ids_required','event_pairs.csv',
             'event_selection.csv','initial_geographic_events.csv','excluded_picks.csv']:
    (fixture/'data/hayward'/name).write_text('invented fixture; not scientific input\n')
(fixture/'configs/hayward.cfg').write_text('ray_spacing 0.5\n')
(fixture/'CMakeLists.txt').write_text('# Test intercepts configure before any compilation.\n')
(fixture/'src/stub.cpp').write_text('// No solver is built in this execution-record test.\n')
fake = fixture/'bin/cmake'
fake.write_text('#!/usr/bin/env python3\nimport os,sys,time\nif os.environ["EXECUTION_CHECK_MODE"] == "sleep":\n    time.sleep(60)\nelse:\n    sys.exit(7)\n')
fake.chmod(0o755)
env = dict(os.environ, PATH=str(fixture/'bin')+os.pathsep+os.environ['PATH'],
           PYTHONDONTWRITEBYTECODE='1', EXECUTION_CHECK_MODE='failure')
command = [sys.executable, str(fixture/source.name), '--variant','configure_failure','--phase','preflight']
result = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
assert result.returncode == 1
failed_path = fixture/'data/hayward_configure_failure/preflight_execution.json'
failed = json.loads(failed_path.read_text())
assert failed['phase']=='preflight' and failed['status']=='failed' and failed['return_code']==7
assert failed['completed_commands'][0]['return_code']==7
assert failed['current_child_pid'] == failed['completed_commands'][0]['pid']
before = hashlib.sha256(failed_path.read_bytes()).hexdigest()
repeat = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
assert repeat.returncode==2 and hashlib.sha256(failed_path.read_bytes()).hexdigest()==before

# Interrupt only an invented driver. Its surviving invented child is identified
# and cleaned up explicitly; no real run is signaled by this test.
env['EXECUTION_CHECK_MODE']='sleep'
command[command.index('configure_failure')]='interrupted'
with (target/'interrupted_driver_stdout.txt').open('wb') as stdout, (target/'interrupted_driver_stderr.txt').open('wb') as stderr:
    process = subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    child_pid = None
    try:
        marker = fixture/'data/hayward_interrupted/preflight_execution.json'
        deadline = time.time()+10
        while time.time()<deadline:
            if marker.exists():
                data=json.loads(marker.read_text())
                child_pid=data.get('current_child_pid')
                if child_pid: break
            time.sleep(.05)
        assert child_pid
        process.send_signal(signal.SIGTERM)
        assert process.wait(timeout=10)==143
        interrupted=json.loads(marker.read_text())
        assert interrupted['status']=='interrupted' and interrupted['signal']==15
        assert interrupted['return_code']==143 and interrupted['child_return_code_at_driver_signal'] is None
        assert interrupted['current_command_return_code'] is None
    finally:
        if process.poll() is None:
            process.kill(); process.wait()
        if child_pid and Path('/proc/'+str(child_pid)+'/cmdline').exists():
            assert str(fake).encode() in Path('/proc/'+str(child_pid)+'/cmdline').read_bytes()
            os.kill(child_pid, signal.SIGTERM)

# Exercise successful command recording using the exact maintained helpers.
tree=ast.parse(source.read_text())
helper_names={'relative','utc_now','write_execution','start_execution','record_failure','run'}
namespace=dict(Path=Path,ROOT=root,out=target/'success',env=dict(os.environ),args=SimpleNamespace(threads=4),
    execution=None,execution_path=None,active_process=None,os=os,json=json,subprocess=subprocess,
    datetime=datetime,timezone=timezone)
namespace['out'].mkdir()
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in helper_names]), str(source),'exec'),namespace)
namespace['start_execution']('preflight')
namespace['run']([sys.executable,'-c','print("invented command success")'],'invented_success')
success=json.loads((namespace['out']/'preflight_execution.json').read_text())
assert success['current_command_return_code']==0 and success['completed_commands'][0]['return_code']==0
assert success['status']=='running'  # A command success is not complete preflight success.

# Compare the untouched numerical validation block with the frozen 002 source.
old=ast.parse((root/'tmp/hayward_runs/first_arrival_002/source/run_hayward_first_arrival.py').read_text())
def phase(tree):
    return next(n for n in tree.body if isinstance(n,ast.If) and isinstance(n.test,ast.Compare)
                and isinstance(n.test.left,ast.Attribute) and n.test.left.attr=='phase')
def validation(body):
    start=next(i for i,n in enumerate(body) if isinstance(n,ast.Assign)
               and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='absolute')
    result=[]
    for n in body[start:]:
        if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call):
            f=n.value.func
            if (isinstance(f,ast.Name) and f.id=='write_execution') or (isinstance(f,ast.Attribute) and isinstance(f.value,ast.Name) and f.value.id=='execution'):
                continue
        result.append(ast.dump(n))
    return result
newbody=next(n for n in phase(tree).body if isinstance(n,ast.Try)).body
assert validation(phase(old).body)==validation(newbody)
summary={'status':'passed','scope':'Invented execution-lifecycle checks; no numerical solver or actual preflight executed',
 'checks':['configure child failure records actual code7 and PID','same-variant rerun rejected without changing marker',
 'SIGTERM driver records143 and unknown still-running child status','invented child explicitly cleaned up',
 'successful command records code0 without marking whole preflight finished','full numerical preflight validator AST unchanged'],
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'frozen_002_runner_sha256':hashlib.sha256((root/'tmp/hayward_runs/first_arrival_002/source/run_hayward_first_arrival.py').read_bytes()).hexdigest(),
 'test_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'invented_records':{'failure':failed,'interrupted':interrupted,'success':success}}
(target/'checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='invented_records'},indent=2))
