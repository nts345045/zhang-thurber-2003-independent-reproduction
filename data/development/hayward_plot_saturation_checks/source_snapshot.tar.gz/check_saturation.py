#!/usr/bin/env python3
"""Check fixed-scale display metadata; this does not run an inversion."""
import ast
import csv
import hashlib
import json
import os
from pathlib import Path
import sys
import numpy as np
from scipy.interpolate import RegularGridInterpolator

root = Path.cwd()
baseline = root.parents[1]
out = root / 'tmp/hayward_variant_checks'
os.environ.setdefault('MPLCONFIGDIR', str(root / 'tmp/matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def function(path):
    tree = ast.parse(path.read_text())
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'color_range')
    namespace = {'np': np}
    exec(compile(ast.Module(body=[node]), str(path), 'exec'), namespace)
    return namespace['color_range'], ast.dump(node)


color_range, local_ast = function(root / 'plot_hayward.py')
baseline_function, baseline_ast = function(baseline / 'plot_hayward.py')
assert local_ast == baseline_ast
cases = [([0, 1], 'neither'), ([-1, 0, 1], 'min'), ([0, 1, 2], 'max'), ([-1, 0, 1, 2], 'both')]
for samples, expected in cases:
    result = color_range(samples, 0, 1)
    assert result['extend'] == expected
    assert result == baseline_function(samples, 0, 1)
    assert result['below_limit'] == sum(v < 0 for v in samples)
    assert result['above_limit'] == sum(v > 1 for v in samples)
for samples in ([], [np.nan], [np.inf], [-np.inf]):
    try:
        color_range(samples, 0, 1)
    except ValueError:
        pass
    else:
        raise AssertionError('Invalid plotted data accepted')


def rows(path):
    with path.open(newline='') as f:
        return list(csv.DictReader(f))


def grid(path):
    data = rows(path)
    axes = [np.array(sorted({float(r[k]) for r in data})) for k in ('x', 'y', 'z')]
    a = np.empty(tuple(len(x) for x in axes))
    for r in data:
        idx = tuple(np.searchsorted(x, float(r[k])) for x, k in zip(axes, ('x', 'y', 'z')))
        a[idx] = float(r['v'])
    return RegularGridInterpolator(axes, a, bounds_error=True)


paths = [baseline / 'data/hayward' / (m + '_grid.csv') for m in ('initial', 'standard', 'dd')]
input_hashes = {str(p.relative_to(baseline)): digest(p) for p in paths}
zvalues = [float(r['z']) for r in rows(paths[0])]
x = np.linspace(-35, 35, 141)
z = np.linspace(min(zvalues), max(zvalues), int(round((max(zvalues) - min(zvalues)) / .25)) + 1)
xx, zz = np.meshgrid(x, z)
standard, dd = grid(paths[1]), grid(paths[2])
sections, all_standard, all_dd = [], [], []
for y in range(-30, 31, 10):
    points = np.column_stack([xx.ravel(), np.full(xx.size, y), zz.ravel()])
    vs, vd = standard(points), dd(points)
    all_standard.extend(vs)
    all_dd.extend(vd)
    sections.append(dict(y_km=y, standard_velocity=color_range(vs, 3.5, 7),
                         dd_velocity=color_range(vd, 3.5, 7),
                         dd_minus_standard=color_range(vd - vs, -.8, .8)))
vs, vd = np.array(all_standard), np.array(all_dd)
actual = dict(standard_velocity=color_range(vs, 3.5, 7),
              dd_velocity=color_range(vd, 3.5, 7),
              shared_velocity_colorbar=color_range(np.concatenate([vs, vd]), 3.5, 7),
              dd_minus_standard=color_range(vd - vs, -.8, .8), sections=sections)
for name in ('standard_velocity', 'dd_velocity', 'dd_minus_standard'):
    for field in ('sampled_points', 'below_limit', 'above_limit'):
        assert actual[name][field] == sum(s[name][field] for s in sections)
assert actual['shared_velocity_colorbar']['extend'] == 'min'
assert actual['dd_minus_standard']['extend'] == 'both'
assert all(digest(p) == input_hashes[str(p.relative_to(baseline))] for p in paths)

# Independent reconstruction of exported fixture display metadata.
fixture = root / 'tmp/hayward_variant_checks/data'
metrics = json.loads((fixture / 'figure_metrics.json').read_text())
vertical = rows(fixture / 'vertical_sections.csv')
resolution = rows(fixture / 'resolution_sections.csv')
for kind, mapping, source in [
    ('figure10', [('standard_velocity', 'standard_v', 3.5, 7), ('dd_velocity', 'dd_v', 3.5, 7),
                  ('dd_minus_standard', 'dd_minus_standard', -.8, .8)], vertical),
    ('figure11', [('resolution', 'resolution_diagonal', 0, 1),
                  ('noise', 'independent_pick_sigma_velocity_km_s', 0, metrics['color_saturation']['figure11']['noise']['color_limits'][1])], resolution)]:
    for key, field, low, high in mapping:
        values = [float(r[field]) for r in source]
        item = metrics['color_saturation'][kind][key]
        assert item['actual_min_max'] == [min(values), max(values)]
        assert item['below_limit'] == sum(v < low for v in values)
        assert item['above_limit'] == sum(v > high for v in values)
        assert item['sampled_points'] == len(values)
        assert item['color_limits'] == [low, high]
        for section in metrics['color_saturation'][kind]['sections']:
            subset = [float(r[field]) for r in source if float(r['y']) == section['y_km']]
            assert section[key] == color_range(subset, low, high)

fig, axes = plt.subplots(1, 2, figsize=(8, 3))
for ax, values, limits, cmap, label in zip(axes, [vs, vd - vs], [(3.5, 7), (-.8, .8)],
                                         ['viridis', 'RdBu_r'], ['Absolute velocity (km/s)', 'DD minus absolute (km/s)']):
    im = ax.pcolormesh(values.reshape((7 * len(z), len(x))), cmap=cmap, vmin=limits[0], vmax=limits[1], shading='auto')
    stats = color_range(values, *limits)
    bar = fig.colorbar(im, ax=ax, extend=stats['extend'])
    assert bar.extend == stats['extend']
    ax.set_title(label)
    ax.set_xticks([])
    ax.set_yticks([])
fig.suptitle('Display check using saved final standard/DD sections')
fig.tight_layout(rect=(0, 0, 1, .9))
fig.savefig(str(out / 'saturation_display.png'), dpi=140)
plt.close(fig)
summary = dict(status='passed', scope='Fixed-scale color saturation reporting; no inversion or baseline plot regeneration',
    helper_edge_cases=8, identical_helper_in_both_scripts=True, input_sha256=input_hashes,
    source_sha256={'baseline/plot_hayward.py': digest(baseline / 'plot_hayward.py'),
                   'integration/plot_hayward.py': digest(root / 'plot_hayward.py'),
                   'check_saturation.py': digest(Path(__file__))},
    actual_baseline_figure10_sections=actual,
    fixture_export_counts_and_ranges_verified=True,
    actual_model_colorbar_extensions_verified=['min', 'both'],
    actual_ranges_from='Saved standard/DD grid interpolation at the same seven Y sections and X/Z sampling as Figure 10',
    interpretation='Counts describe sampled display points, not independent observations or nodal counts. Fixed color limits are unchanged.',
    fixture_metrics_sha256=digest(fixture / 'figure_metrics.json'),
    fixture_display_extensions=metrics['color_saturation'])
(out / 'saturation_checks.json').write_text(json.dumps(summary, indent=2, allow_nan=False) + '\n')
print(json.dumps({k: v for k, v in actual.items() if k != 'sections'}, indent=2))
