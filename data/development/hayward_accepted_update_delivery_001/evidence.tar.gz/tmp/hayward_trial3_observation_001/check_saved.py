"""Preserve a closed accepted-trial ledger and a partial history prefix; stdlib only."""
from pathlib import Path
from fractions import Fraction as Q
import collections
import csv
import datetime
import gzip
import hashlib
import io
import json
import sys
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RUN = ROOT / 'data/hayward_old_kernel_backtracking_001'
SOURCE = ROOT / 'tmp/hayward_old_kernel_backtracking_runs/001/source'
OUT = HERE / 'saved'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def save(path, data):
    with path.open('xb') as stream:
        stream.write(data)


def dump(path, record):
    save(path, (json.dumps(record, indent=2, sort_keys=True) + '\n').encode())


def rows(path):
    with path.open(newline='') as stream:
        reader = csv.DictReader(stream)
        assert reader.fieldnames and len(set(reader.fieldnames)) == len(reader.fieldnames)
        for row in reader:
            assert None not in row and None not in row.values(), str(path)
            yield dict(row)


def compressed_csv(path, fieldnames, records):
    with path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with io.TextIOWrapper(zipped, encoding='utf-8', newline='') as stream:
                writer = csv.DictWriter(stream, fieldnames=fieldnames, lineterminator='\n')
                writer.writeheader()
                writer.writerows(records)


def run():
    OUT.mkdir()  # A failed attempt is preserved; never overwrite it.
    observed = datetime.datetime.utcnow().isoformat() + 'Z'
    manifest_path = RUN / 'dd_inversion_run_manifest.json'
    manifest = json.loads(manifest_path.read_text())
    input_pins = {str(manifest_path.relative_to(ROOT)): sha(manifest_path)}
    # These inputs and the executed source are immutable; no live log is hashed.
    for name in ['initial_events.csv', 'stations.csv', 'observations.csv', 'initial_grid.csv', 'run.cfg']:
        path = RUN / name
        actual = sha(path)
        assert actual == manifest['input_sha256'][name], name
        input_pins[str(path.relative_to(ROOT))] = actual
        if name != 'observations.csv':
            save(OUT / name, path.read_bytes())
    for name in ['src/main.cpp', 'src/ray_checks.hpp', 'src/core.hpp', 'src/forward.hpp']:
        path = SOURCE / name
        assert sha(path) == manifest['source_sha256'][name], name
        input_pins[str(path.relative_to(ROOT))] = sha(path)
    binary = ROOT / manifest['binary']
    assert sha(binary) == manifest['binary_sha256']
    input_pins[str(binary.relative_to(ROOT))] = manifest['binary_sha256']

    source = (SOURCE / 'src/main.cpp').read_text()
    gate = source[source.index('void inversion_ray_gate('):source.index('void write_trial_solve(')]
    required = ['nonfinite_or_empty_ray', 'local_stopping_failed', 'path_outside_domain_or_empty',
                'source_endpoint_changed', 'receiver_endpoint_changed', 'initializer_not_attempted', 'initializer_failed']
    assert all('"' + reason + '"' in gate for reason in required)
    assert 'if (failed.empty()) return;' in gate
    checked = source[source.index('const auto checked_rays ='):source.index('auto log = output(dir + "/" + mode + "_history.csv")')]
    assert checked.index('inversion_ray_gate(') < checked.index('return result;')
    trial_source = source[source.index('double before = objective(g, e, r)'):source.index('if (!log) throw std::runtime_error("Cannot finish inverse history record")')]
    anchors = ['nr = checked_rays(ng, ee, false, "line_search_trial", ls);',
               'after = objective(ng, ee, nr);', 'after <= before ? "accepted"',
               'finish_output(trials, trials_path);', 'g = ng;', 'e = ee;', 'log << it']
    assert [trial_source.index(a) for a in anchors] == sorted(trial_source.index(a) for a in anchors)
    assert source.index('ray_converged += r[index].converged;') < source.index('double before = objective(g, e, r)')
    assert 'f << std::setprecision(12);' in source
    assert 'trials << std::setprecision(17)' in trial_source
    excerpt_ranges = [(60, 74), (987, 1069), (1133, 1240), (1295, 1401)]
    source_lines = source.splitlines(keepends=True)
    excerpt = ''.join('// Executed main.cpp lines {}..{}\n'.format(a, b) +
                      ''.join(source_lines[a - 1:b]) for a, b in excerpt_ranges)
    save(OUT / 'executed_main_excerpts.cpp', excerpt.encode())

    # The next iteration's ledger proves iteration zero has left its closing scope.
    # Only existence is observed; iteration one's bytes are neither read nor hashed.
    assert (RUN / 'dd_iteration_1_trials.csv').is_file()
    ledger_path = RUN / 'dd_iteration_0_trials.csv'
    ledger_bytes = ledger_path.read_bytes()
    assert ledger_bytes.endswith(b'\n')
    save(OUT / ledger_path.name, ledger_bytes)
    input_pins[str(ledger_path.relative_to(ROOT))] = digest_bytes(ledger_bytes)
    trials = list(rows(OUT / ledger_path.name))
    assert len(trials) == 4
    for index, row in enumerate(trials):
        assert row['iteration'] == row['stage'] == '0' and int(row['trial']) == index
        assert Q(row['step_fraction']) == Q(1, 2 ** index)
        assert row['objective_before'] == '1812.1565900877081'
        if index < 3:
            assert row['status'] == 'local_stopping_rejected' and row['objective_evaluated'] == '0'
            assert row['objective_after'] == ''
            assert row['failure_prefix'] == str(RUN / ('dd_rejected_trial_it_0_ls_' + str(index)))
        else:
            assert row['status'] == 'accepted' and row['objective_evaluated'] == '1'
            assert row['objective_after'] == '1409.1648979520239' and row['failure_prefix'] == ''
    accepted = trials[-1]
    before, after = [Q(float(accepted[k])) for k in ('objective_before', 'objective_after')]
    assert 0 < after < before

    # Read exactly two complete lines. The source file can grow after this read.
    history_path = RUN / 'dd_history.csv'
    with history_path.open('rb') as stream:
        history_prefix = stream.readline() + stream.readline()
    assert history_prefix.count(b'\n') == 2 and history_prefix.endswith(b'\n')
    save(OUT / 'dd_history_header_first_row.partial.csv', history_prefix)
    history = list(rows(OUT / 'dd_history_header_first_row.partial.csv'))
    assert len(history) == 1
    history = history[0]
    assert history['iteration'] == history['stage'] == '0' and history['step_fraction'] == '0.125'
    for k in ('objective_before', 'objective_after'):
        assert history[k] == format(float(accepted[k]), '.12g')
    for k in ['ray_count', 'ray_converged_count', 'ray_initialization_attempted_count', 'ray_initialization_succeeded_count']:
        assert history[k] == '14262'
    assert history['ray_selected_fmm_count'] == '14261'

    events, stations = list(rows(OUT / 'initial_events.csv')), list(rows(OUT / 'stations.csv'))
    assert len(events) == 1092 and len(stations) == 372
    assert [int(r['id']) for r in events] == list(range(len(events)))
    assert [int(r['id']) for r in stations] == list(range(len(stations)))
    channel_fields = ['network_code', 'station_code', 'location_code', 'channel_code', 'channel_seed_id', 'channel_fdsn_source_id']
    pick_fields = ['pick_resource_id', 'pick_time_utc', 'pick_uncertainty_s', 'pick_uncertainty_confidence_level',
                   'pick_source_sha256', 'arrival_resource_id', 'arrival_time_weight']
    pair_records, catalog_refs = {}, []
    type_counts = collections.Counter()
    cross_epochs = 0
    for index, row in enumerate(rows(RUN / 'observations.csv')):
        typ = int(row['type'])
        assert typ in (0, 1)
        type_counts[typ] += 1
        sides = [('i', 'station')] if typ == 0 else [('i', 'station'), ('j', 'station_j')]
        if typ == 0:
            assert row['j'] == row['station_j'] == '-1'
            assert all(row[k] == '' for k in ['event_j_resource_id', 'origin_j_resource_id', 'pick_j_resource_id', 'arrival_j_resource_id', 'metadata_epoch_j_start', 'metadata_epoch_j_end'])
        for side, receiver_field in sides:
            e, s = int(row[side]), int(row[receiver_field])
            assert 0 <= e < len(events) and 0 <= s < len(stations)
            event, station = events[e], stations[s]
            assert row['event_' + side + '_resource_id'] == event['event_resource_id']
            assert row['origin_' + side + '_resource_id'] == event['origin_resource_id']
            assert all(row[k] == station[k] for k in channel_fields)
            for end in ('start', 'end'):
                key = 'metadata_epoch_' + ('' if side == 'i' else 'j_') + end
                assert row[key] == station['metadata_epoch_' + end]
            assert row['channel_' + ('' if side == 'i' else 'j_') + 'source_sha256'] == station['source_sha256']
            pick = {k: row[k.replace('pick_', 'pick_' + side + '_').replace('arrival_', 'arrival_' + side + '_')] for k in pick_fields}
            assert pick['pick_resource_id'] and pick['arrival_resource_id'] and pick['pick_source_sha256']
            metadata = dict(event=e, station=s, native_flat_index=e * len(stations) + s,
                            event_resource_id=event['event_resource_id'], origin_resource_id=event['origin_resource_id'],
                            metadata_epoch_start=station['metadata_epoch_start'], metadata_epoch_end=station['metadata_epoch_end'],
                            **dict((k, station[k]) for k in channel_fields))
            metadata.update(pick)
            pair = (e, s)
            if pair in pair_records:
                assert pair_records[pair]['metadata'] == metadata
            else:
                pair_records[pair] = dict(metadata=metadata, uses=0, absolute_uses=0)
            pair_records[pair]['uses'] += 1
            pair_records[pair]['absolute_uses'] += int(typ == 0)
            catalog_refs.append(dict(observation_index=index, type=typ, side=side, event=e, station=s))
        is_cross = typ == 1 and int(row['station']) != int(row['station_j'])
        assert int(row['cross_metadata_epoch']) == int(is_cross)
        cross_epochs += int(is_cross)
    assert type_counts == {0: 14262, 1: 44718}
    assert len(pair_records) == 14262 and len(catalog_refs) == 103698
    assert all(r['absolute_uses'] == 1 for r in pair_records.values())
    pairs = [dict(r['metadata'], catalog_uses=r['uses'], absolute_uses=r['absolute_uses']) for p, r in sorted(pair_records.items())]
    compressed_csv(OUT / 'native_pairs.csv.gz', list(pairs[0]), pairs)
    compressed_csv(OUT / 'catalog_row_side_refs.csv.gz', ['observation_index', 'type', 'side', 'event', 'station'], catalog_refs)
    # Confirm every immutable source read remains unchanged. Re-read only the
    # same history prefix, never the growing whole history or next trial ledger.
    for name, expected in input_pins.items():
        assert sha(ROOT / name) == expected, name
    with history_path.open('rb') as stream:
        assert stream.read(len(history_prefix)) == history_prefix
    output_pins = {str(p.relative_to(HERE)): sha(p) for p in sorted(OUT.iterdir())}
    result = dict(status='passed_closed_trial_three_saved_readback', observed_utc=observed,
                  source_sha256=sha(Path(__file__).resolve()), input_sha256=input_pins, output_sha256=output_pins,
                  immutable_inputs_unchanged=True, closed_trial_ledger=trials, accepted_trial=accepted,
                  objective_decrease_binary64_exact=str(before - after), relative_decrease_exact=str((before - after) / before),
                  objective_decrease_display=float(before - after), relative_decrease_display=float((before - after) / before),
                  objective_basis='sum of squared fixed row-multiplied observation residuals plus final log-slowness smoothing; solve damping is not added to this objective',
                  history_first_row=history, history_scope='Header and first completed row only; ray counts, maxima and RMS are PREUPDATE iteration-zero quantities. No source whole-file hash or terminal history claim.',
                  history_prefix_sha256=digest_bytes(history_prefix), history_prefix_bytes=len(history_prefix),
                  next_iteration_ledger_exists=True, next_iteration_ledger_read_or_hashed=False,
                  source_excerpts=dict(source=str((SOURCE / 'src/main.cpp').relative_to(ROOT)), line_ranges=excerpt_ranges),
                  required_trial_gate=required, trial_gate_evidence='Acceptance is source-bound: the executed control flow calls the full required forward gate with derivatives=false before evaluating this objective. No successful-trial ray status or accepted model was emitted here.',
                  native_counts=dict(events=len(events), receiver_epochs=len(stations), used_events=len(set(p[0] for p in pair_records)), used_receiver_epochs=len(set(p[1] for p in pair_records)), pairs=len(pair_records), observation_rows=sum(type_counts.values()), observation_types=dict(type_counts), catalog_side_uses=len(catalog_refs), cross_epoch_rows=cross_epochs, empty_location_pairs=sum(r['location_code'] == '' for r in pairs)),
                  identity_mapping='Exact copied initial_events/stations contain all native columns; native_pairs deduplicates event/epoch/pick/association identities; catalog_row_side_refs addresses the pinned original observations.csv without duplicating it. Coordinates in those input copies are initial/provider state, not accepted trial-three coordinates.',
                  live_run_status='ongoing observation only; no terminal or final scientific-quality claim',
                  generic_last_accepted_files='Not read or hashed. These are failure snapshots and can still describe the pre-update state or be replaced by later failures; they are not a successful-trial-three export.',
                  numerical_calls=0, signals_sent=0, restarts=0, original_file_writes=0)
    dump(HERE / 'receipt.json', result)
    print(json.dumps(dict(status=result['status'], receipt_sha256=sha(HERE / 'receipt.json'), native_counts=result['native_counts'], objective_decrease=result['objective_decrease_display'])))


if __name__ == '__main__':
    try:
        run()
    except BaseException as error:
        if not (HERE / 'failure.json').exists():
            dump(HERE / 'failure.json', dict(status='failed_preserved', error=repr(error), traceback=traceback.format_exc(), source_sha256=sha(Path(__file__).resolve())))
        raise
