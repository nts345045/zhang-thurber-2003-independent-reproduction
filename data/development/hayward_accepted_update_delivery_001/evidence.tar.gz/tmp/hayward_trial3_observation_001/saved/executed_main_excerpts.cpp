// Executed main.cpp lines 60..74
std::ofstream output(std::string p) {
  std::ofstream f(p);
  if (!f)
    throw std::runtime_error("Cannot write " + p);
  f << std::setprecision(12);
  return f;
}
// Failure evidence must be fully written before a trial can be rejected safely.
void finish_output(std::ofstream &stream, const std::string &path) {
  stream.flush();
  stream.close();
  if (!stream) throw std::runtime_error("Cannot finish writing " + path);
}
void require_new_outputs(const std::string &prefix, const std::vector<std::string> &suffixes) {
  for (const auto &suffix : suffixes)
// Executed main.cpp lines 987..1069
}
// An invalid forward evaluation must not enter an inverse Jacobian or objective.
// These are the existing local checks, not a global first-arrival certificate.
struct InverseRayRejection : std::runtime_error {
  bool only_local_stopping;
  InverseRayRejection(const std::string &message, bool only_local)
      : std::runtime_error(message), only_local_stopping(only_local) {}
};
void inversion_ray_gate(const std::string &prefix, const Grid &g,
                        const std::vector<Event> &events, const std::vector<Event> &stations,
                        const std::vector<Ray> &rr, const std::vector<int> &used,
                        bool initialization_required, bool derivatives) {
  if (rr.size() != events.size() * stations.size())
    throw std::runtime_error("Incomplete inverse forward ray array");
  std::vector<std::pair<int, std::string>> failed;
  for (int n : used) {
    const auto &ray = rr[n];
    const size_t i = n / stations.size(), k = n % stations.size();
    std::string reasons;
    const auto check = [&](bool valid, const char *reason) {
      if (!valid) { if (!reasons.empty()) reasons += ";"; reasons += reason; }
    };
    check(finite_ray(ray), "nonfinite_or_empty_ray");
    check(ray.converged, "local_stopping_failed");
    check(ray_path_in_domain(g, ray), "path_outside_domain_or_empty");
    check(!ray.path.empty() && ray.path.front() == events[i].p, "source_endpoint_changed");
    check(!ray.path.empty() && ray.path.back() == stations[k].p, "receiver_endpoint_changed");
    if (initialization_required) check(ray.initialization_attempted, "initializer_not_attempted");
    if (initialization_required || ray.initialization_attempted)
      check(ray.initialization_succeeded, "initializer_failed");
    if (derivatives) {
      check(ray.dv.size() == g.v.size(), "velocity_derivative_dimension");
      check(ray.length.size() == g.v.size(), "path_length_dimension");
    }
    if (!reasons.empty()) failed.emplace_back(n, std::move(reasons));
  }
  if (failed.empty()) return;
  require_new_outputs(prefix, {"_ray_status.csv", "_ray_failures.csv", "_ray_paths.csv"});
  auto identified_events = events;
  for (auto &event : identified_events)
    if (!event.metadata.empty())
      set_metadata(event.metadata, "coordinate_basis",
          "independent failed forward evaluation at recorded coordinates; see companion context for evaluation phase");
  write_ray_status(prefix + "_ray_status.csv", identified_events, stations, rr, &used, &g, 17, derivatives);
  auto out = output(prefix + "_ray_failures.csv");
  out << "event,station,reasons,derivatives_requested,velocity_derivatives,path_lengths,expected_velocity_nodes";
  csv_metadata_header(out, identified_events.front().metadata, "source_");
  csv_metadata_header(out, stations.front().metadata, "receiver_");
  out << '\n';
  for (const auto &failure : failed) {
    const size_t i = failure.first / stations.size(), k = failure.first % stations.size();
    const auto &ray = rr[failure.first];
    out << i << ',' << k << ',' << csv_quote(failure.second) << ',' << derivatives
        << ',' << ray.dv.size() << ',' << ray.length.size() << ',' << g.v.size();
    csv_metadata_values(out, identified_events[i].metadata);
    csv_metadata_values(out, stations[k].metadata);
    out << '\n';
  }
  finish_output(out, prefix + "_ray_failures.csv");
  auto paths = output(prefix + "_ray_paths.csv");
  paths << std::setprecision(17) << "event,station,node,x,y,z";
  csv_metadata_header(paths, identified_events.front().metadata, "source_");
  csv_metadata_header(paths, stations.front().metadata, "receiver_");
  paths << '\n';
  for (const auto &failure : failed) {
    const size_t i = failure.first / stations.size(), k = failure.first % stations.size();
    const auto &path = rr[failure.first].path;
    for (size_t node = 0; node < path.size(); ++node) {
      paths << i << ',' << k << ',' << node;
      for (double value : path[node]) paths << ',' << value;
      csv_metadata_values(paths, identified_events[i].metadata);
      csv_metadata_values(paths, stations[k].metadata);
      paths << '\n';
    }
  }
  finish_output(paths, prefix + "_ray_paths.csv");
  const bool only_local = std::all_of(failed.begin(), failed.end(), [](const auto &failure) {
    return failure.second == "local_stopping_failed";
  });
  throw InverseRayRejection("Inverse forward evaluation rejected " + std::to_string(failed.size()) +
      " rays; see " + prefix + "_ray_status.csv; first: " +
      ray_identity_context(events, stations, failed.front().first / stations.size(),
                           failed.front().first % stations.size()), only_local);
// Executed main.cpp lines 1133..1240
  auto e = read_events(dir + "/initial_events.csv"),
       stations = read_events(dir + "/stations.csv");
  auto data = observations(dir + "/observations.csv", e, stations,
                           !authoritative_input(c, dir) && authoritative_geometry(c, dir));
  const auto used = observed_rays(data, e.size(), stations);
  const bool authoritative = authoritative_input(c, dir);
  if (authoritative)
    validate_identities(e, stations, data);
  else if (authoritative_geometry(c, dir))
    validate_identities(e, stations, data, true);
  const auto weights = stage_weights(c, data);
  if (!(c.get("stage_length") > 0))
    throw std::runtime_error("stage_length must be positive");
  Grid g = read_grid(dir + "/initial_grid.csv");
  bool locate = mode == "loc1d" || mode == "loc3d";
  if (mode == "loc3d")
    g = read_grid(dir + "/truth_grid.csv");
  int ne = e.size(), ns = stations.size(), off = 4 * ne,
      n = off + (locate ? 0 : g.size());
  ForwardFields fields;
  int current_iteration = -1;
  const auto failure_prefix = [&](const std::string &phase, int trial) {
    return dir + "/" + mode + (phase == "line_search_trial" ?
        "_rejected_trial_it_" + std::to_string(current_iteration) + "_ls_" + std::to_string(trial) :
        "_failed_forward");
  };
  const auto checked_rays = [&](const Grid &model, const std::vector<Event> &sources,
                                bool derivatives, const std::string &phase, int trial) {
    const std::string prefix = failure_prefix(phase, trial);
    if (phase == "line_search_trial")
      require_new_outputs(prefix, {"_ray_status.csv", "_ray_failures.csv", "_ray_paths.csv",
          "_events.csv", "_grid.csv", "_context.csv", "_accepted_events.csv", "_accepted_grid.csv"});
    try {
      auto result = rays(model, sources, stations, c, derivatives, &used, &fields, false);
      inversion_ray_gate(prefix, model, sources, stations, result, used,
                         auxiliary_spacing(c) > 0, derivatives);
      return result;
    } catch (const std::exception &error) {
      // A failed trial is distinct from the last accepted state. In particular,
      // do not write a candidate to the conventional final inversion filenames.
      auto identified_sources = sources, accepted_sources = e;
      if (authoritative || authoritative_geometry(c, dir)) {
        for (auto &event : identified_sources)
          set_metadata(event.metadata, "coordinate_basis", "independent failed " + phase + " forward evaluation; not a final inversion result");
        for (auto &event : accepted_sources)
          set_metadata(event.metadata, "coordinate_basis", "independent last accepted inversion state, or starting state before the first accepted update");
      }
      write_events(identified_sources, prefix + "_events.csv", 17);
      write_grid(model, prefix + "_grid.csv", 17);
      write_events(accepted_sources, dir + "/" + mode + "_last_accepted_events.csv", 17);
      write_grid(g, dir + "/" + mode + "_last_accepted_grid.csv", 17);
      if (phase == "line_search_trial") {
        write_events(accepted_sources, prefix + "_accepted_events.csv", 17);
        write_grid(g, prefix + "_accepted_grid.csv", 17);
      }
      auto context = output(prefix + "_context.csv");
      context << "mode,iteration,phase,line_search_trial,derivatives_requested,initialization_required,significant_digits,message\n"
              << mode << ',' << current_iteration << ',' << phase << ',' << trial << ',' << derivatives
              << ',' << (auxiliary_spacing(c) > 0) << ",17," << csv_quote(error.what()) << '\n';
      finish_output(context, prefix + "_context.csv");
      throw;
    }
  };
  auto log = output(dir + "/" + mode + "_history.csv");
  log << "iteration,stage,absolute_rms,catalog_rms,precise_rms,velocity_step,"
         "location_step,step_fraction,objective_before,objective_after,lsqr_"
         "iterations,lsqr_relative_normal_residual,lsqr_converged,ray_count,"
         "ray_converged_count,ray_projected_gradient_max,ray_raw_gradient_max,"
         "ray_initialization_attempted_count,ray_initialization_succeeded_count,"
         "ray_selected_fmm_count\n";
  auto preflight = output(dir + "/" + mode + "_matrix_preflight.csv");
  preflight << "iteration,observation_rows,active_data_rows,smoothing_rows,columns,"
               "damped_rows,damped_entries,csr_payload_bytes,numeric_observation_bytes,"
               "residual_weight_bytes,lsqr_row_workspace_bound_bytes\n";
  for (int it = 0; it < int(c.get("iterations")); it++) {
    current_iteration = it;
    const bool preflight_only = setting(c, "matrix_preflight_only", 0) != 0;
    auto r = preflight_only ? rays(g, e, stations, c, true, &used, &fields, false) :
                             checked_rays(g, e, true, "current_model", -1);
    if (preflight_only) {
      write_ray_status(dir + "/" + mode + "_preflight_ray_status.csv", e, stations, r, &used, &g);
      for (int index : used)
        if (!finite_ray(r[index]) ||
            !ray_path_in_domain(g, r[index]) ||
            r[index].path.front() != e[index / ns].p ||
            r[index].path.back() != stations[index % ns].p ||
            (r[index].initialization_attempted && !r[index].initialization_succeeded) ||
            r[index].dv.size() != g.v.size() || r[index].length.size() != g.v.size())
          throw std::runtime_error("Preflight ray evaluation failed; see identified status table; " +
                                   ray_identity_context(e, stations, index / ns, index % ns));
    }
    size_t ray_converged = 0, attempted = 0, succeeded = 0, selected_fmm = 0;
    double ray_projected_max = 0, ray_raw_max = 0;
    for (int index : used) {
      ray_converged += r[index].converged;
      attempted += r[index].initialization_attempted;
      succeeded += r[index].initialization_succeeded;
      selected_fmm += r[index].selected_fmm_seed;
      ray_projected_max = std::max(ray_projected_max, r[index].gradient);
      ray_raw_max = std::max(ray_raw_max, r[index].raw_gradient);
    }
    int stage = std::min(2, int(it / c.get("stage_length")));
    Matrix A(n);
    Vec residual(data.size()), w(data.size());
    double ss[3] = {}, count[3] = {};
    // Residual scale is estimated separately for each data type; a 0.01 s floor
    // avoids eliminating the rounded, nearly exact synthetic differential
    // times.
// Executed main.cpp lines 1295..1401
    LSQRInfo linear_info;
    Vec delta = solve(std::move(A), c.get("damping"), &linear_info);
    auto objective = [&](const Grid &gg, const std::vector<Event> &ee,
                         const std::vector<Ray> &rr) {
      double value = 0;
      for (size_t q = 0; q < data.size(); q++) {
        double res = data[q].value - prediction(data[q], rr, ee, ns);
        value += w[q] * w[q] * res * res;
      }
      if (!locate) {
        Matrix S(n);
        smooth(S, gg, off, c.get("smoothing"));
        value += dot(S.rhs, S.rhs);
      }
      return value;
    };
    double before = objective(g, e, r), after = before, step = 1;
    Grid ng;
    std::vector<Event> ee;
    bool accepted = false;
    int quality_rejections = 0, objective_evaluations = 0;
    const std::string solve_prefix = dir + "/" + mode + "_iteration_" + std::to_string(it) + "_solve";
    const std::string trials_path = dir + "/" + mode + "_iteration_" + std::to_string(it) + "_trials.csv";
    require_new_outputs(trials_path, {""});
    auto trials = output(trials_path);
    trials << std::setprecision(17) << "iteration,stage,trial,step_fraction,status,objective_evaluated,objective_before,objective_after,failure_prefix\n";
    const auto record_trial = [&](int trial, const char *status, bool evaluated, const std::string &prefix = "") {
      trials << it << ',' << stage << ',' << trial << ',' << step << ',' << status << ',' << evaluated << ',' << before << ',';
      if (evaluated) trials << after;
      trials << ',' << csv_quote(prefix) << '\n';
      trials.flush();
      if (!trials) throw std::runtime_error("Cannot finish trial record " + trials_path);
    };
    for (int ls = 0; ls < 12; ls++, step *= 0.5) {
      ng = g;
      ee = e;
      bool valid = true;
      for (int i = 0; i < ne; i++) {
        const Vec *axes[] = {&g.x, &g.y, &g.z};
        for (int k = 0; k < 3; k++)
          ee[i].p[k] = std::clamp(e[i].p[k] + step * delta[4 * i + k],
                                  axes[k]->front(), axes[k]->back());
        ee[i].t += step * delta[4 * i + 3];
      }
      if (!locate)
        for (int k = 0; k < g.size(); k++) {
          ng.v[k] = g.v[k] * std::exp(-step * delta[off + k]);
          if (!std::isfinite(ng.v[k]) || ng.v[k] <= 0)
            valid = false;
        }
      if (!valid) {
        record_trial(ls, "invalid_trial_model", false);
        continue;
      }
      std::vector<Ray> nr;
      try {
        nr = checked_rays(ng, ee, false, "line_search_trial", ls);
      } catch (const InverseRayRejection &failure) {
        if (!failure.only_local_stopping) throw;
        if (quality_rejections == 0)
          write_trial_solve(solve_prefix, c, mode, it, stage, g, e, data, delta,
                            residual, w, linear_info, before, locate);
        ++quality_rejections;
        record_trial(ls, "local_stopping_rejected", false, failure_prefix("line_search_trial", ls));
        continue; // Never evaluate or accept an unsupported forward objective.
      }
      ++objective_evaluations;
      after = objective(ng, ee, nr);
      record_trial(ls, after <= before ? "accepted" : "objective_rejected", true);
      if (after <= before) {
        accepted = true;
        break;
      }
    }
    finish_output(trials, trials_path);
    if (quality_rejections > 0 && objective_evaluations == 0)
      throw std::runtime_error("No objective-evaluable trial after local ray rejection; see " + trials_path);
    double dv = 0, dx = 0;
    if (!accepted) {
      step = 0;
      after = before;
    } else {
      for (int i = 0; i < ne; i++)
        for (int k = 0; k < 3; k++)
          dx = std::max(dx, std::abs(ee[i].p[k] - e[i].p[k]));
      g = ng;
      e = ee;
    }
    if (!locate)
      for (int k = 0; k < g.size(); k++)
        dv = std::max(dv, std::abs(step * delta[off + k]));
    log << it << ',' << stage << ','
        << (count[0] > 0 ? std::sqrt(ss[0] / count[0]) : NAN) << ','
        << (count[1] > 0 ? std::sqrt(ss[1] / count[1]) : NAN) << ','
        << (count[2] > 0 ? std::sqrt(ss[2] / count[2]) : NAN) << ',' << dv
        << ',' << dx << ',' << step << ',' << before << ',' << after << ','
        << linear_info.iterations << ',' << linear_info.relative_normal_residual
        << ',' << linear_info.converged << ',' << used.size() << ','
        << ray_converged << ',' << ray_projected_max << ',' << ray_raw_max << ','
        << attempted << ',' << succeeded << ',' << selected_fmm << '\n';
    log.flush();
    if (!log) throw std::runtime_error("Cannot finish inverse history record");
    std::cout << mode << " iteration " << it << " stage " << stage << " rms "
              << (count[0] > 0 ? std::sqrt(ss[0] / count[0]) : NAN) << ' '
              << (count[2] > 0 ? std::sqrt(ss[2] / count[2]) : NAN)
              << " objective " << before << " -> " << after << " step " << step
              << std::endl;
