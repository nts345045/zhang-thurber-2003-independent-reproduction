# First accepted Hayward objective step: saved observation

`check_saved.py` reads the closed iteration-zero trial ledger and only the header
and first completed row of the growing history. It checks the executed source
against the run manifest, joins both observation sides to original event/origin
and receiver-epoch metadata, and saves compact catalog row references. It does
not call a solver, ray evaluator, or live-run controller.

The ledger records local-stopping rejections at fractions 1, 1/2 and 1/4, followed
by an objective-accepted trial at 1/8. The objective uses fixed observation row
multipliers and final log-slowness smoothing. Acceptance implies that the
required forward gate returned successfully, by the pinned executed control
flow. No successful trial-three model, path or per-ray status is exported there.

The first history row's 14,262 ray flags and gradient maxima describe the
pre-update evaluation. Input event coordinates saved here are the initial state;
they are not accepted trial-three coordinates. Generic `dd_last_accepted_*`
failure snapshots are not read or treated as successful-trial evidence. This
observation does not attest terminal completion, later trials, full derivative
accuracy or first-arrival correctness.

Run once from the integration root with bytecode disabled:

```sh
PYTHONDONTWRITEBYTECODE=1 /usr/libexec/platform-python3.6 tmp/hayward_trial3_observation_001/check_saved.py
```

The script refuses an existing `saved/` directory. A failure and partial copies
remain preserved. `receipt.json` hashes immutable inputs and the closed ledger;
the history is represented only by its two-line prefix hash. Original
`observations.csv` remains external and hash-bound; `catalog_row_side_refs.csv.gz`
uses its zero-based data-row indices and `i`/`j` sides. All copied metadata retains
the original empty location strings and both receiver-epoch joins.
