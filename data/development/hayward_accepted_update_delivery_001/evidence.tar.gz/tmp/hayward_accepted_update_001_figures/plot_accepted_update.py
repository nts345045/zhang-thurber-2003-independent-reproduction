"""Plot closed saved states only; never call or import a project numerical helper."""
import collections
import csv
import datetime
from fractions import Fraction as Q
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RUN = ROOT / 'data/hayward_old_kernel_backtracking_001'
OBS = ROOT / 'tmp/hayward_iteration1_trial0_observation_001'
PRIOR = ROOT / 'tmp/hayward_trial3_observation_001'
TITLE = 'Accepted update 1; run incomplete'
INPUT_PINS = {}
OUTPUTS = []


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def pin(path, expected=None):
    value = sha(path)
    assert expected is None or value == expected, str(path)
    INPUT_PINS[str(path.relative_to(ROOT))] = value
    return value


def save(name, data):
    with (HERE / name).open('xb') as f:
        f.write(data)
    OUTPUTS.append(name)


def dump(name, obj, compressed=False):
    data = (json.dumps(obj, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()
    save(name, gzip.compress(data, mtime=0) if compressed else data)


def read_rows(path):
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt', newline='') as f:
        reader = csv.DictReader(f)
        assert len(set(reader.fieldnames)) == len(reader.fieldnames)
        out = [dict(r) for r in reader]
    assert all(None not in r and None not in r.values() for r in out)
    return out


def value(text):
    x = float(text)
    assert math.isfinite(x)
    return Q(x)


def described(q):
    return {'exact_binary64_rational': str(q), 'display': float(q)}


def extrema(values, unit, keys):
    lo, hi = min(range(len(values)), key=values.__getitem__), max(range(len(values)), key=values.__getitem__)
    return {'unit': unit, 'minimum': dict(described(values[lo]), row=keys[lo]),
            'maximum': dict(described(values[hi]), row=keys[hi]),
            'zero_count': sum(x == 0 for x in values)}


def verify_receipts():
    pin(OBS / 'receipt.json', '8da05d5120abc9e79e66a4d9409da2aa9e87eda0b55d2cfb920652ada81aae63')
    pin(OBS / 'execution_receipt.json', 'bc1d6f7eea72b124bf121ba1f95d452ed604c0809da68b36c494e53846cfbbbb')
    receipt = json.loads((OBS / 'receipt.json').read_text())
    execution = json.loads((OBS / 'execution_receipt.json').read_text())
    assert receipt['status'] == 'passed_closed_iteration1_trial0_observation'
    assert execution['status'] == 'passed' and execution['return_code'] == 0 and execution['child_reaped'] is True
    assert execution['receipt_sha256'] == sha(OBS / 'receipt.json')
    assert execution['checker_sha256'] == receipt['checker_sha256']
    pin(OBS / 'check_saved.py', receipt['checker_sha256'])
    assert execution['output_sha256'] == receipt['output_sha256']
    for name, expected in receipt['input_sha256'].items():
        pin(ROOT / name, expected)
    for name, expected in receipt['output_sha256'].items():
        pin(OBS / name, expected)
    prior = json.loads((PRIOR / 'receipt.json').read_text())
    assert prior['status'] == 'passed_closed_trial_three_saved_readback'
    assert prior['accepted_trial']['iteration'] == '0' and prior['accepted_trial']['trial'] == '3'
    assert prior['accepted_trial']['status'] == 'accepted' and prior['accepted_trial']['step_fraction'] == '0.125'
    pin(PRIOR / 'check_saved.py', prior['source_sha256'])
    pin(PRIOR / 'execution_receipt.json')
    pe = json.loads((PRIOR / 'execution_receipt.json').read_text())
    assert pe['status'] == 'completed_and_reaped' and pe['checker_reaped'] is True and pe['return_code'] == 0
    assert pe['file_sha256']['receipt.json'] == sha(PRIOR / 'receipt.json')
    for name, expected in pe['file_sha256'].items():
        pin(PRIOR / name, expected)
    for name, expected in prior['output_sha256'].items():
        pin(PRIOR / name, expected)
    manifest = json.loads((RUN / 'dd_inversion_run_manifest.json').read_text())
    for name in ['initial_events.csv', 'initial_grid.csv', 'stations.csv', 'observations.csv', 'run.cfg']:
        assert sha(RUN / name) == manifest['input_sha256'][name]
    source_path = ROOT / 'tmp/hayward_old_kernel_backtracking_runs/001/source/src/main.cpp'
    assert sha(source_path) == manifest['source_sha256']['src/main.cpp']
    source = source_path.read_text()
    assert 'write_events(accepted, prefix + "_accepted_events.csv", 17);' in source
    assert 'nr = checked_rays(ng, ee, false, "line_search_trial", ls);' in source
    assert 'g = ng;\n      e = ee;' in source
    lines = source.splitlines(keepends=True)
    text = ''.join('// Executed main.cpp lines {}..{}; source SHA256 {}\n'.format(a, b, sha(source_path)) +
                   ''.join(lines[a - 1:b]) for a, b in [(1071, 1090), (1346, 1399)])
    save('source_basis.cpp.txt', text.encode())
    return receipt, prior


def main():
    assert not (HERE / 'summary.json').exists(), 'Preserve prior outputs; use a fresh directory.'
    for key, subdir in [('MPLCONFIGDIR', 'cache/matplotlib'), ('XDG_CACHE_HOME', 'cache/xdg'), ('TMPDIR', 'tmp')]:
        path = HERE / subdir
        path.mkdir(parents=True, exist_ok=True)
        os.environ[key] = str(path)
    os.environ['MPLBACKEND'] = 'Agg'
    assert os.environ.get('PYTHONDONTWRITEBYTECODE') == '1'
    receipt, prior = verify_receipts()
    initial = read_rows(RUN / 'initial_events.csv')
    accepted = read_rows(RUN / 'dd_iteration_1_solve_accepted_events.csv')
    stations = read_rows(RUN / 'stations.csv')
    g0, g1 = [read_rows(RUN / name) for name in ['initial_grid.csv', 'dd_iteration_1_solve_accepted_grid.csv']]
    assert len(initial) == len(accepted) == 1092 and len(stations) == 372 and len(g0) == len(g1) == 462
    assert [int(r['id']) for r in initial] == [int(r['id']) for r in accepted] == list(range(1092))
    assert [int(r['id']) for r in stations] == list(range(372))
    for a, b in zip(initial, accepted):
        assert all(a[k] == b[k] for k in a if k not in ('x', 'y', 'z', 't'))
        assert b['coordinate_basis'] == 'independent accepted inversion state at iteration 1; original unscaled solve recorded separately'
    for a, b in zip(g0, g1):
        assert all(value(a[k]) == value(b[k]) for k in 'xyz')
        assert value(a['v']) > 0 and value(b['v']) > 0
    axes = {k: sorted(set(value(r[k]) for r in g0)) for k in 'xyz'}
    lattice = [(x, y, z) for z in axes['z'] for y in axes['y'] for x in axes['x']]
    assert [tuple(value(r[k]) for k in 'xyz') for r in g0] == lattice
    depth = Q(8)
    assert depth in axes['z']
    layer = [i for i, r in enumerate(g0) if value(r['z']) == depth]
    assert len(layer) == 77
    pairs = read_rows(PRIOR / 'saved/native_pairs.csv.gz')
    refs = read_rows(PRIOR / 'saved/catalog_row_side_refs.csv.gz')
    pair_map = {(int(r['event']), int(r['station'])): r for r in pairs}
    assert len(pair_map) == len(pairs) == 14262 and len(refs) == 103698
    common = ['network_code', 'station_code', 'location_code', 'channel_code', 'channel_seed_id', 'channel_fdsn_source_id',
              'metadata_epoch_start', 'metadata_epoch_end']
    for (e, s), r in pair_map.items():
        assert r['native_flat_index'] == str(e * len(stations) + s)
        assert all(r[k] == initial[e][k] for k in ['event_resource_id', 'origin_resource_id'])
        assert all(r[k] == stations[s][k] for k in common)
    use_counts, absolute_counts = collections.Counter(), collections.Counter()
    ref_map = {(int(r['observation_index']), r['side']): r for r in refs}
    assert len(ref_map) == len(refs)
    # Join both sides and both epochs directly to the pinned original catalog,
    # retaining row references instead of duplicating its 50 MB of CSV text.
    observation_count = 0
    with (RUN / 'observations.csv').open(newline='') as f:
        for index, row in enumerate(csv.DictReader(f)):
            observation_count += 1
            sides = [('i', 'station', '')] if row['type'] == '0' else [('i', 'station', ''), ('j', 'station_j', 'j_')]
            assert row['type'] in ('0', '1')
            for side, skey, epoch_suffix in sides:
                e, s = int(row[side]), int(row[skey])
                pair = pair_map[e, s]
                ref = ref_map[index, side]
                assert ref == dict(observation_index=str(index), type=row['type'], side=side, event=str(e), station=str(s))
                assert row['event_' + side + '_resource_id'] == initial[e]['event_resource_id']
                assert row['origin_' + side + '_resource_id'] == initial[e]['origin_resource_id']
                assert all(row[k] == stations[s][k] for k in common[:6])
                for end in ('start', 'end'):
                    assert row['metadata_epoch_' + epoch_suffix + end] == stations[s]['metadata_epoch_' + end]
                assert row['channel_' + epoch_suffix + 'source_sha256'] == stations[s]['source_sha256']
                for key in ['pick_resource_id', 'pick_time_utc', 'pick_uncertainty_s', 'pick_uncertainty_confidence_level',
                            'pick_source_sha256', 'arrival_resource_id', 'arrival_time_weight']:
                    assert pair[key] == row[key.replace('pick_', 'pick_' + side + '_').replace('arrival_', 'arrival_' + side + '_')]
                use_counts[e, s] += 1
                absolute_counts[e, s] += int(row['type'] == '0')
    assert observation_count == 58980 and sum(use_counts.values()) == len(refs)
    assert set(e for e, s in pair_map) == set(range(1092)) and set(s for e, s in pair_map) == set(range(372))
    for p, r in pair_map.items():
        assert int(r['catalog_uses']) == use_counts[p] and int(r['absolute_uses']) == absolute_counts[p] == 1
    for name in ['native_pairs.csv.gz', 'catalog_row_side_refs.csv.gz']:
        save(name, (PRIOR / 'saved' / name).read_bytes())
    del refs, ref_map
    deltas = [{k: value(b[k]) - value(a[k]) for k in 'xyzt'} for a, b in zip(initial, accepted)]
    dv = [value(b['v']) - value(a['v']) for a, b in zip(g0, g1)]
    event_records = []
    for e, (a, b, d) in enumerate(zip(initial, accepted, deltas)):
        assert all(axes[k][0] <= value(b[k]) <= axes[k][-1] for k in 'xyz')
        event_records.append({'event': e, 'original': a, 'accepted': b,
                              'original_binary64_hex': {k: float(a[k]).hex() for k in 'xyzt'},
                              'accepted_binary64_hex': {k: float(b[k]).hex() for k in 'xyzt'},
                              'delta_exact': {k: str(d[k]) for k in 'xyzt'}})
    grid_records = [{'node': i, 'original': a, 'accepted': b, 'delta_v_exact': str(dv[i]),
                     'original_binary64_hex': {k: float(a[k]).hex() for k in ('x', 'y', 'z', 'v')},
                     'accepted_binary64_hex': {k: float(b[k]).hex() for k in ('x', 'y', 'z', 'v')}}
                    for i, (a, b) in enumerate(zip(g0, g1))]
    dump('native_identifiers.json.gz', {'title': TITLE, 'coordinate_basis': 'Native saved kilometre coordinates; catalog geographic fields are unchanged identity metadata.',
         'events': event_records, 'receiver_epochs': stations, 'grid_nodes': grid_records,
         'native_pairs': {'file': 'native_pairs.csv.gz', 'sha256': sha(HERE / 'native_pairs.csv.gz')},
         'catalog_row_side_refs': {'file': 'catalog_row_side_refs.csv.gz', 'sha256': sha(HERE / 'catalog_row_side_refs.csv.gz')},
         'authoritative_observations_sha256': sha(RUN / 'observations.csv'), 'input_sha256': INPUT_PINS}, compressed=True)
    horizontal2 = [d['x'] ** 2 + d['y'] ** 2 for d in deltas]
    spatial2 = [d['x'] ** 2 + d['y'] ** 2 + d['z'] ** 2 for d in deltas]
    stats = {'grid_shape_xyz': [len(axes[k]) for k in 'xyz'], 'grid_axes_km_exact': {k: list(map(str, axes[k])) for k in 'xyz'},
             'grid_nodes': len(g0), 'plotted_depth_km_exact': str(depth), 'plotted_nodes': len(layer),
             'grid_delta_v_all': extrema(dv, 'km/s', list(range(len(g0)))),
             'grid_delta_v_layer': extrema([dv[i] for i in layer], 'km/s', layer),
             'event_count': len(initial), 'receiver_epochs': len(stations),
             'channel_seed_ids': len(set(r['channel_seed_id'] for r in stations)),
             'empty_location_epochs': sum(r['location_code'] == '' for r in stations),
             'native_pairs': len(pairs), 'catalog_rows': observation_count, 'catalog_side_uses': sum(use_counts.values()),
             'event_delta': {k: extrema([d[k] for d in deltas], 's' if k == 't' else 'km', list(range(len(initial)))) for k in 'xyzt'},
             'horizontal_displacement_squared': extrema(horizontal2, 'km^2', list(range(len(initial)))),
             'spatial_displacement_squared': extrema(spatial2, 'km^2', list(range(len(initial))))}
    for label, vals in [('horizontal', horizontal2), ('spatial', spatial2)]:
        stats[label + '_displacement_display_km'] = [math.sqrt(float(min(vals))), math.sqrt(float(max(vals)))]
    # A fixed native-coordinate detail window, without magnifying the vectors.
    window = (-4, 0, 20, 24)
    zoom = [i for i, r in enumerate(initial) if window[0] <= value(r['x']) < window[1] and window[2] <= value(r['y']) < window[3]]
    stats['detail_window_km'] = list(window)
    stats['detail_event_ids'] = zoom
    dump('statistics.json', stats)
    identity = {'title': TITLE, 'state': 'Iteration-1 starting state after iteration-0 trial-3 acceptance; run incomplete.',
                'mapping_file': 'native_identifiers.json.gz', 'mapping_sha256': sha(HERE / 'native_identifiers.json.gz'),
                'event_resource_ids': [r['event_resource_id'] for r in initial],
                'origin_resource_ids': [r['origin_resource_id'] for r in initial],
                'receiver_epoch_identities': [{k: r[k] for k in ['id'] + common} for r in stations],
                'input_sha256': INPUT_PINS, 'plot_source_sha256': sha(Path(__file__).resolve()),
                'statistics_sha256': sha(HERE / 'statistics.json'), 'plotted_depth_km': 8,
                'vector_scale': 'One kilometre of plotted arrow displacement is one native kilometre; no vector amplification.',
                'limitations': ['No interpolation, smoothing, fit, ray, field, Jacobian or solver calculation.',
                                'History RMS describes the preupdate state; no postupdate RMS is reported.',
                                'No final convergence, first-arrival accuracy or manuscript-reproduction claim.']}
    for ext in ['png', 'pdf']:
        dump('accepted_update_1.' + ext + '.identifiers.json', dict(identity, expected_output='accepted_update_1.' + ext,
                                                                output_sha256=None, hash_binding='summary.json after the plot is closed'))
    import matplotlib
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize
    from matplotlib.patches import Rectangle
    import numpy
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.titlesize': 12,
                         'axes.spines.top': False, 'axes.spines.right': False, 'pdf.fonttype': 42})
    fig = plt.figure(figsize=(14.6, 6.7), facecolor='white')
    gs = fig.add_gridspec(1, 3, width_ratios=[1.35, 0.62, 1.0], left=.058, right=.97, bottom=.19, top=.80, wspace=.30)
    ax0, ax1, ax2 = [fig.add_subplot(gs[0, i]) for i in range(3)]
    lim = max(abs(float(dv[i])) for i in layer)
    colors = ax0.scatter([float(value(g0[i]['x'])) for i in layer], [float(value(g0[i]['y'])) for i in layer],
                         c=[float(dv[i]) for i in layer], s=22, cmap='RdBu_r', norm=Normalize(-lim, lim),
                         linewidths=.25, edgecolors='#ffffff')
    ax0.set(xlim=(-38, 38), ylim=(-33, 33), xlabel='Native x (km)', ylabel='Native y (km)',
            title='Velocity change at saved z = 8 km\n77 grid nodes; no interpolation')
    cb0 = fig.colorbar(colors, ax=ax0, orientation='horizontal', fraction=.07, pad=.13, aspect=28)
    cb0.set_label('Accepted − initial velocity (km/s)')
    xy = [(float(value(r['x'])), float(value(r['y']))) for r in initial]
    uv = [(float(d['x']), float(d['y'])) for d in deltas]
    mag = [math.sqrt(float(q)) for q in horizontal2]
    norm = Normalize(0, max(mag))
    for ax, indices, size in [(ax1, list(range(1092)), 5), (ax2, zoom, 12)]:
        x, y = [xy[i][0] for i in indices], [xy[i][1] for i in indices]
        dx, dy = [uv[i][0] for i in indices], [uv[i][1] for i in indices]
        ax.scatter(x, y, s=size, c='#a7a7a7', alpha=.6, linewidths=0, zorder=1)
        arrows = ax.quiver(x, y, dx, dy, [mag[i] for i in indices], cmap='viridis', norm=norm,
                          angles='xy', scale_units='xy', scale=1, width=.0035, headwidth=3.5,
                          headlength=4, headaxislength=3.5, minlength=0, zorder=3)
        ax.set(xlabel='Native x (km)', ylabel='Native y (km)')
    ax1.set(xlim=(-11.5, 11.5), ylim=(-32, 32), title='All 1,092 events\nHorizontal displacement')
    ax1.add_patch(Rectangle((window[0], window[2]), window[1] - window[0], window[3] - window[2],
                            facecolor='none', edgecolor='#cc4422', linewidth=1.2))
    ax2.set(xlim=(-4.2, .2), ylim=(19.8, 24.2), title='Detail: {} events\nSame native distance scale for arrows'.format(len(zoom)))
    ax2.quiverkey(arrows, .77, -.105, .1, '0.1 km', labelpos='E', coordinates='axes', color='#343434')
    cb2 = fig.colorbar(arrows, ax=ax2, orientation='horizontal', fraction=.07, pad=.23, aspect=28)
    cb2.set_label('Horizontal displacement magnitude (km)')
    for ax in [ax0, ax1, ax2]:
        ax.set_aspect('equal', adjustable='box')
        ax.grid(True, color='#e3e7eb', linewidth=.55, zorder=0)
        ax.set_axisbelow(True)
    fig.suptitle(TITLE, x=.058, y=.952, ha='left', fontsize=21, fontweight='bold', color='#172735')
    fig.text(.058, .887, 'Closed iteration-1 accepted state compared with the original identified starting inputs', fontsize=12, color='#405463')
    fig.text(.058, .039, 'Gray dots: original events. Arrows: accepted − original, without magnification. Red box: detail window.\n'
                        'Saved grid-node values only. This figure does not report post-update RMS or final convergence.', fontsize=9, color='#52606c')
    for ext in ['png', 'pdf']:
        path = HERE / ('accepted_update_1.' + ext)
        assert not path.exists()
        metadata = {'Title': TITLE, 'Author': '', 'Subject': 'Saved accepted update; incomplete run'} if ext == 'pdf' else {'Title': TITLE, 'Description': 'Native saved coordinates; no interpolation or solver calls.'}
        fig.savefig(path, dpi=220, facecolor='white', metadata=metadata)
        OUTPUTS.append(path.name)
    plt.close(fig)
    # Stable inputs are rechecked after plotting; live logs are never opened.
    for name, expected in INPUT_PINS.items():
        assert sha(ROOT / name) == expected, name
    result = {'status': 'completed_saved_update_visualization', 'title': TITLE,
              'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': os.getpid(),
              'input_sha256': INPUT_PINS, 'plot_source_sha256': sha(Path(__file__).resolve()),
              'readme_sha256': sha(HERE / 'README.md'), 'statistics': stats,
              'output_sha256': {name: sha(HERE / name) for name in OUTPUTS},
              'runtime': {'python': sys.version, 'executable': sys.executable, 'python_binary_sha256': sha(Path(sys.executable).resolve()),
                          'matplotlib': matplotlib.__version__, 'numpy': numpy.__version__,
                          'environment': {k: os.environ[k] for k in ['MPLCONFIGDIR', 'XDG_CACHE_HOME', 'TMPDIR', 'MPLBACKEND', 'PYTHONDONTWRITEBYTECODE']}},
              'scope': identity['limitations'], 'original_file_writes': 0, 'solver_calls': 0, 'integration_calls': 0,
              'field_calls': 0, 'jacobian_calls': 0, 'fit_or_interpolation_calls': 0}
    dump('summary.json', result)
    print(json.dumps({'status': result['status'], 'summary_sha256': sha(HERE / 'summary.json'),
                      'png_sha256': sha(HERE / 'accepted_update_1.png'), 'pdf_sha256': sha(HERE / 'accepted_update_1.pdf')}))


if __name__ == '__main__':
    main()
