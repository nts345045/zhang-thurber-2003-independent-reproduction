"""Read only closed trial evidence; retain one literal prefix of a growing ledger."""
import collections
import csv
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RUN = ROOT/'data/hayward_old_kernel_backtracking_001'
PRIOR = ROOT/'tmp/hayward_trial3_observation_001'
PREFIX = RUN/'dd_rejected_trial_it_1_ls_0'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def rows(path):
    opening = gzip.open(str(path), 'rt', newline='') if str(path).endswith('.gz') else path.open(newline='')
    with opening as stream:
        reader = csv.DictReader(stream)
        assert reader.fieldnames and len(reader.fieldnames) == len(set(reader.fieldnames))
        for row in reader:
            assert None not in row and None not in row.values()
            yield row


def dump(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False); stream.write('\n')


def compressed(path, records, identity):
    dump(Path(str(path)+'.identifiers.json'), dict(identity, expected_file=str(path.relative_to(ROOT))))
    with path.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as packed:
            with io.TextIOWrapper(packed, encoding='utf8', newline='') as stream:
                writer = csv.DictWriter(stream, fieldnames=list(records[0]), lineterminator='\n')
                writer.writeheader(); writer.writerows(records)


def main():
    output = HERE/'saved'; output.mkdir()
    pins = {}
    def pin(path, expected=None):
        digest = sha(path); assert expected is None or digest == expected
        pins[str(path.relative_to(ROOT))] = digest
    prior = json.loads((PRIOR/'receipt.json').read_text()); pin(PRIOR/'receipt.json')
    assert prior['status'] == 'passed_closed_trial_three_saved_readback'
    for name in ('saved/native_pairs.csv.gz', 'saved/catalog_row_side_refs.csv.gz'):
        pin(PRIOR/name, prior['output_sha256'][name])
    manifest = json.loads((RUN/'dd_inversion_run_manifest.json').read_text()); pin(RUN/'dd_inversion_run_manifest.json')
    for name in ('observations.csv', 'initial_events.csv', 'stations.csv', 'initial_grid.csv', 'run.cfg'):
        pin(RUN/name, manifest['input_sha256'][name])
    source = ROOT/'tmp/hayward_old_kernel_backtracking_runs/001/source/src/main.cpp'
    pin(source, manifest['source_sha256']['src/main.cpp'])
    for suffix in ('ray_status.csv', 'ray_failures.csv', 'context.csv', 'accepted_events.csv', 'accepted_grid.csv'):
        pin(Path(str(PREFIX)+'_'+suffix))
    for name in ('dd_iteration_1_solve_context.csv', 'dd_iteration_1_solve_accepted_events.csv',
                 'dd_iteration_1_solve_accepted_grid.csv'):
        pin(RUN/name)
    assert sha(RUN/'dd_iteration_1_solve_accepted_grid.csv') == sha(Path(str(PREFIX)+'_accepted_grid.csv'))
    solve_events = list(rows(RUN/'dd_iteration_1_solve_accepted_events.csv'))
    trial_events = list(rows(Path(str(PREFIX)+'_accepted_events.csv')))
    assert len(solve_events) == len(trial_events) == 1092
    state_joins = 0
    for left, right in zip(solve_events, trial_events):
        assert list(left) == list(right)
        assert left['coordinate_basis'] == 'independent accepted inversion state at iteration 1; original unscaled solve recorded separately'
        assert right['coordinate_basis'] == 'independent last accepted inversion state, or starting state before the first accepted update'
        for key in left:
            if key != 'coordinate_basis':
                assert left[key] == right[key]; state_joins += 1
    ledger = RUN/'dd_iteration_1_trials.csv'
    with ledger.open('rb') as stream:
        prefix = stream.readline()+stream.readline()
    assert prefix.endswith(b'\n') and prefix.count(b'\n') == 2
    record = list(csv.DictReader(prefix.decode().splitlines())); assert len(record) == 1
    record = record[0]
    assert record['iteration'] == '1' and record['trial'] == record['stage'] == '0'
    assert record['step_fraction'] == '1' and record['status'] == 'local_stopping_rejected'
    assert record['objective_evaluated'] == '0' and record['objective_after'] == '' and record['failure_prefix'] == str(PREFIX)
    failures = list(rows(Path(str(PREFIX)+'_ray_failures.csv')))
    status = {(r['event'], r['station']): r for r in rows(Path(str(PREFIX)+'_ray_status.csv'))}
    assert len(status) == 14262 and len(failures) == 234
    failed = {(r['event'], r['station']) for r in failures}; assert len(failed) == len(failures)
    selected = []; joins = 0
    for failure in failures:
        r = status[failure['event'], failure['station']]
        assert failure['reasons'] == 'local_stopping_failed'
        for key in set(failure)&set(r):
            assert failure[key] == r[key]; joins += 1
        assert r['ray_converged'] == r['ray_derivatives_evaluated'] == '0'
        assert all(r['source_d'+k] == '' for k in 'xyz')
        assert all(r[k] == '1' for k in ('ray_finite','ray_initialization_attempted','ray_initialization_succeeded',
                   'ray_path_in_domain','ray_exact_source_endpoint','ray_exact_receiver_endpoint'))
        selected.append(r)
    pairs = {(r['event'], r['station']): r for r in rows(PRIOR/'saved/native_pairs.csv.gz')}
    for r in selected:
        p = pairs[r['event'], r['station']]
        assert r['source_event_resource_id'] == p['event_resource_id'] and r['source_origin_resource_id'] == p['origin_resource_id']
        assert all(r['receiver_'+k] == p[k] for k in ('network_code','station_code','location_code','channel_code','channel_seed_id','channel_fdsn_source_id','metadata_epoch_start','metadata_epoch_end'))
    observations = []
    for index, row in enumerate(rows(RUN/'observations.csv')):
        involved = (row['i'], row['station']) in failed or (row['type'] == '1' and (row['j'], row['station_j']) in failed)
        if involved:
            observations.append(dict(original_observation_index=index, **row))
    identity = dict(iteration=1, trial=0, live_run_ongoing=True, trial_ledger_row=record,
        native_pairs_file=str((PRIOR/'saved/native_pairs.csv.gz').relative_to(ROOT)),
        complete_both_side_catalog_mapping=str((RUN/'observations.csv').relative_to(ROOT)),
        failed_native_contexts=selected, input_sha256=pins,
        scope='Closed failed-trial rows and their original complete catalog observations; original flags and valid blank locations retained.')
    compressed(output/'failed_status.csv.gz', selected, identity)
    compressed(output/'affected_original_observations.csv.gz', observations, identity)
    partial = output/'dd_iteration_1_trials_header_first_row.partial.csv'
    dump(Path(str(partial)+'.identifiers.json'), dict(identity, expected_file=str(partial.relative_to(ROOT)),
        prefix_only=True, complete_source_ledger_hashed=False))
    with partial.open('xb') as stream:
        stream.write(prefix)
    for name, digest in pins.items():
        assert sha(ROOT/name) == digest
    with ledger.open('rb') as stream:
        assert stream.read(len(prefix)) == prefix
    receipt = dict(status='passed_closed_iteration1_trial0_observation', observed_utc=datetime.datetime.utcnow().isoformat()+'Z',
        checker_sha256=sha(Path(__file__)), input_sha256=pins,
        output_sha256={str(p.relative_to(HERE)):sha(p) for p in sorted(output.iterdir())},
        closed_trial_row=record, source_ledger_scope='Only the first complete header/row prefix; no hash or terminal claim for the growing source ledger.',
        prefix_sha256=hashlib.sha256(prefix).hexdigest(), prefix_bytes=len(prefix),
        total_used_rays=len(status), failed_rays=len(failures), shared_native_field_joins=joins,
        failure_reasons=dict(collections.Counter(r['reasons'] for r in failures)),
        failed_events=len({r['event'] for r in failures}), failed_receiver_epochs=len({r['station'] for r in failures}),
        affected_original_observations=len(observations), native_channels=dict(collections.Counter(r['receiver_channel_seed_id'] for r in failures)),
        iterations=dict(at_1000=sum(int(r['ray_iterations'])==1000 for r in selected), below_1000=sum(int(r['ray_iterations'])<1000 for r in selected),
                        minimum=min(int(r['ray_iterations']) for r in selected), maximum=max(int(r['ray_iterations']) for r in selected)),
        projected_gradient_range=[min(float(r['ray_projected_gradient']) for r in selected),max(float(r['ray_projected_gradient']) for r in selected)],
        finite_initializer_box_endpoint_checks=True, derivative_flags_zero_source_partials_blank=True,
        accepted_event_state_field_joins=state_joins, accepted_grid_byte_identical=True,
        current_accepted_state_scope='Closed iteration-1 solve and rejected-trial accepted states have identical grid bytes and all event fields except the two explicitly checked coordinate_basis provenance descriptions. They represent the iteration-1 accepted starting state, following iteration-0 acceptance; no final inversion-state claim.',
        objective_scope='This iteration recomputes fixed row weights; its baseline must not be directly compared with the differently weighted prior iteration objective. This trial did not reach objective evaluation.',
        live_run_ongoing=True, numerical_calls=0, signals_sent=0, restarts=0, original_file_writes=0)
    dump(HERE/'receipt.json', receipt)
    print(json.dumps(dict(status=receipt['status'], receipt_sha256=sha(HERE/'receipt.json'),failed_rays=len(failures),affected_observations=len(observations))))


if __name__ == '__main__':
    main()
