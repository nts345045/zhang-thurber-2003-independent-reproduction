#!/usr/bin/env python3
"""Detached owner of one reviewed guarded DD wrapper; no numerical changes."""
import hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
PLAN=ROOT/'data/development/hayward_guarded_dd_launch_plan_001'
def sha(p):
 d=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):d.update(b)
 return d.hexdigest()
def now():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def save(p,d):
 q=p.with_name(p.name+'.new');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(p)
plan=json.loads((PLAN/'plan.json').read_text())
assert sha(PLAN/'plan.json')=='271a02a4ee019eb92193306c264e661550fcce0e658b06b46e144e87fcb2e7e3'
assert sha(PLAN/'launch_review.json')=='1a21cd54df9a7956735658a748e0225966681b59cf31e55dfb27e47e0b425e4b'
for n,d in plan['source_sha256'].items():assert sha(ROOT/n)==d,n
for n,d in plan['input_sha256'].items():assert sha(ROOT/plan['preflight']/n)==d,n
OUT=ROOT/plan['output'];assert not OUT.exists() and not (ROOT/plan['build']).exists()
command=plan['command'];started=now();os.chdir(str(ROOT))
with (HERE/'stdout.log').open('xb') as stdout,(HERE/'stderr.log').open('xb') as stderr:
 child=subprocess.Popen(command,cwd=str(ROOT),stdout=stdout,stderr=stderr,start_new_session=True,
  env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1'))
 def forward(signum,unused):
  try:os.killpg(child.pid,signum)
  except ProcessLookupError:pass
 for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,forward)
 save(HERE/'launch.json',dict(status='running',controller_pid=os.getpid(),driver_pid=child.pid,started_utc=started,
  command=command,controller_sha256=sha(Path(__file__)),plan_sha256=sha(PLAN/'plan.json'),launch_review_sha256=sha(PLAN/'launch_review.json'),
  output=plan['output'],build=plan['build'],threads=4))
 code=child.wait()
receipt=dict(status='completed' if code==0 else 'failed',driver_return_code=code,child_reaped=True,
 controller_pid=os.getpid(),driver_pid=child.pid,started_utc=started,finished_utc=now(),command=command,
 launch_sha256=sha(HERE/'launch.json'),controller_sha256=sha(Path(__file__)),
 log_sha256={n:sha(HERE/n) for n in ['stdout.log','stderr.log']})
for name in ['dd_inversion_execution.json','dd_inversion_run_manifest.json','dd_output_contract.json']:
 if (OUT/name).exists():receipt[name+'_sha256']=sha(OUT/name)
save(HERE/'completion.json',receipt)
if OUT.exists():
 target=OUT/'controller_provenance';target.mkdir()
 for name in ['controller.py','launch.json','completion.json','stdout.log','stderr.log']:
  shutil.copyfile(str(HERE/name),str(target/name))
sys.exit(code)
